Version History:


1.0.1
#####
Fixed incorrect URL parameter in generate_user_key function.
Fixed issue with api_paste_code in paste function.



1.0.0
#####
Initial specification of all Pastebin API features.